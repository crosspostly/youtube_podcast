# PowerShell script to get video title from VIDEO_TITLE.txt or youtube_details.txt
$ErrorActionPreference = "Continue"

try {
    $basePath = (Get-Location).Path
    
    # Try to read from VIDEO_TITLE.txt first
    $titleFile = Join-Path $basePath "VIDEO_TITLE.txt"
    if (Test-Path $titleFile) {
        $title = (Get-Content $titleFile -Raw).Trim()
        if ($title) {
            Write-Output $title
            exit 0
        }
    }
    
    # Fallback to youtube_details.txt
    $youtubeFile = Join-Path $basePath "youtube_details.txt"
    if (Test-Path $youtubeFile) {
        $content = Get-Content $youtubeFile -Raw
        if ($content -match "TITLE:\s*(.+?)(?:\r?\n|\r)") {
            $title = $Matches[1].Trim()
            Write-Output $title
            exit 0
        }
    }
    
    # Default fallback
    Write-Output "final_video"
    exit 0
    
} catch {
    Write-Output "final_video"
    exit 0
}

