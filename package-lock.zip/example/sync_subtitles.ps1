# PowerShell script to synchronize subtitles with audio duration
$ErrorActionPreference = "Continue"

try {
    $basePath = (Get-Location).Path
    Write-Host "[INFO] Synchronizing subtitles with audio..."
    
    # Get audio duration
    $audioFile = Join-Path $basePath "final_audio.wav"
    $audioDuration = [double](& ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $audioFile)
    Write-Host "[INFO] Audio duration: $audioDuration seconds ($([TimeSpan]::FromSeconds($audioDuration).ToString('mm\:ss')))"
    
    # Read subtitles file
    $subtitlesPath = Join-Path $basePath "subtitles.srt"
    if (-not (Test-Path $subtitlesPath)) {
        Write-Host "[ERROR] subtitles.srt not found!"
        exit 1
    }
    
    $subtitlesContent = Get-Content $subtitlesPath -Raw
    Write-Host "[INFO] Original subtitles file read"
    
    # Find the last timestamp in subtitles
    $lastTimestampPattern = "(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})"
    $matches = [regex]::Matches($subtitlesContent, $lastTimestampPattern)
    
    if ($matches.Count -eq 0) {
        Write-Host "[ERROR] No timestamps found in subtitles!"
        exit 1
    }
    
    # Get the last end timestamp
    $lastMatch = $matches[$matches.Count - 1]
    $lastHour = [int]$lastMatch.Groups[5].Value
    $lastMinute = [int]$lastMatch.Groups[6].Value
    $lastSecond = [int]$lastMatch.Groups[7].Value
    $lastMillisecond = [int]$lastMatch.Groups[8].Value
    
    $lastSubtitleTime = $lastHour * 3600 + $lastMinute * 60 + $lastSecond + $lastMillisecond / 1000.0
    
    Write-Host "[INFO] Last subtitle timestamp: $lastSubtitleTime seconds ($([TimeSpan]::FromSeconds($lastSubtitleTime).ToString('mm\:ss')))"
    
    # Calculate scaling factor
    if ($lastSubtitleTime -eq 0) {
        Write-Host "[ERROR] Invalid last subtitle time!"
        exit 1
    }
    
    $scaleFactor = $audioDuration / $lastSubtitleTime
    Write-Host "[INFO] Scaling factor: $scaleFactor"
    
    if ($scaleFactor -lt 0.5 -or $scaleFactor -gt 2.0) {
        Write-Host "[WARNING] Scaling factor is extreme ($scaleFactor). This might indicate a problem."
        $confirm = Read-Host "Continue anyway? (y/n)"
        if ($confirm -ne "y") {
            exit 1
        }
    }
    
    # Function to scale a timestamp
    function Scale-Timestamp {
        param(
            [string]$timestamp
        )
        
        if ($timestamp -match "(\d{2}):(\d{2}):(\d{2}),(\d{3})") {
            $hours = [int]$Matches[1]
            $minutes = [int]$Matches[2]
            $seconds = [int]$Matches[3]
            $milliseconds = [int]$Matches[4]
            
            $totalSeconds = $hours * 3600 + $minutes * 60 + $seconds + $milliseconds / 1000.0
            $scaledSeconds = $totalSeconds * $scaleFactor
            
            $scaledTimeSpan = [TimeSpan]::FromSeconds($scaledSeconds)
            $formatted = "{0:D2}:{1:D2}:{2:D2},{3:D3}" -f $scaledTimeSpan.Hours, $scaledTimeSpan.Minutes, $scaledTimeSpan.Seconds, $scaledTimeSpan.Milliseconds
            
            return $formatted
        }
        return $timestamp
    }
    
    # Process all timestamps line by line
    $lines = $subtitlesContent -split "`n"
    $processedLines = @()
    
    foreach ($line in $lines) {
        if ($line -match "(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})") {
            # This is a timestamp line
            $scaledStart = Scale-Timestamp "$($Matches[1]):$($Matches[2]):$($Matches[3]),$($Matches[4])"
            $scaledEnd = Scale-Timestamp "$($Matches[5]):$($Matches[6]):$($Matches[7]),$($Matches[8])"
            $processedLines += "$scaledStart --> $scaledEnd"
        } else {
            $processedLines += $line
        }
    }
    
    $processedContent = $processedLines -join "`n"
    
    # Create backup
    $backupPath = Join-Path $basePath "subtitles.srt.backup"
    Copy-Item $subtitlesPath $backupPath -Force
    Write-Host "[INFO] Backup created: subtitles.srt.backup"
    
    # Save synchronized subtitles
    $processedContent | Set-Content $subtitlesPath -Encoding UTF8 -NoNewline
    Write-Host "[SUCCESS] Subtitles synchronized and saved!"
    Write-Host "[INFO] Original file backed up to: subtitles.srt.backup"
    
} catch {
    Write-Host "[ERROR] PowerShell error: $_"
    Write-Host "Error details: $($_.Exception.Message)"
    exit 1
}

