
# PowerShell script to get the video title
$ErrorActionPreference = "SilentlyContinue"
$basePath = (Get-Location).Path
$title = ""

# 1. Try VIDEO_TITLE.txt (highest priority)
$videoTitlePath = Join-Path $basePath "VIDEO_TITLE.txt"
if (Test-Path $videoTitlePath) {
    $title = (Get-Content $videoTitlePath -Raw).Trim()
}

# 2. If not found, try youtube_details.txt
if (-not $title) {
    $detailsPath = Join-Path $basePath "youtube_details.txt"
    if (Test-Path $detailsPath) {
        $content = Get-Content $detailsPath -Raw
        # Regex to find text after "TITLE:" until a line of dashes or end of file
        if ($content -match "(?sm)TITLE:\s*([\s\S]*?)(?:\n----|$)") {
            $title = $Matches[1].Trim()
        }
    }
}

# 3. Fallback to a default name if still not found
if (-not $title) {
    $title = "final_video"
}

Write-Output $title
