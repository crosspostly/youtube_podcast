
# PowerShell script to synchronize subtitles with audio duration
$ErrorActionPreference = "Continue"

try {
    $basePath = (Get-Location).Path
    Write-Host "[INFO] Synchronizing subtitles with audio..."
    
    # Get audio duration
    $audioFile = Join-Path $basePath "final_audio.wav"
    if (-not (Test-Path $audioFile)) { Write-Host "[ERROR] final_audio.wav not found!"; exit 1 }
    
    $audioDurationStr = (& ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $audioFile).Trim()
    $audioDuration = [double]::Parse($audioDurationStr, [System.Globalization.CultureInfo]::InvariantCulture)
    
    Write-Host "[INFO] Audio duration: $audioDuration seconds"
    
    # Read subtitles file
    $subtitlesPath = Join-Path $basePath "subtitles.srt"
    if (-not (Test-Path $subtitlesPath)) { Write-Host "[ERROR] subtitles.srt not found!"; exit 1 }
    
    $subtitlesContent = Get-Content $subtitlesPath -Raw
    
    # Find the last timestamp
    $lastTimestampPattern = "(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})"
    $matches = [regex]::Matches($subtitlesContent, $lastTimestampPattern)
    
    if ($matches.Count -eq 0) { Write-Host "[ERROR] No timestamps found in subtitles!"; exit 1 }
    
    $lastMatch = $matches[$matches.Count - 1]
    $lastSubtitleTime = ([int]$lastMatch.Groups[5].Value * 3600) + ([int]$lastMatch.Groups[6].Value * 60) + [int]$lastMatch.Groups[7].Value + ([int]$lastMatch.Groups[8].Value / 1000.0)
    
    Write-Host "[INFO] Last subtitle timestamp: $lastSubtitleTime seconds"
    
    if ($lastSubtitleTime -eq 0) { Write-Host "[ERROR] Invalid last subtitle time!"; exit 1 }
    
    $scaleFactor = $audioDuration / $lastSubtitleTime
    Write-Host "[INFO] Scaling factor: $scaleFactor"
    
    function Scale-Timestamp {
        param([string]$timestamp)
        if ($timestamp -match "(\d{2}):(\d{2}):(\d{2}),(\d{3})") {
            $totalSeconds = ([int]$Matches[1] * 3600) + ([int]$Matches[2] * 60) + [int]$Matches[3] + ([int]$Matches[4] / 1000.0)
            $scaledSeconds = $totalSeconds * $scaleFactor
            $scaledTimeSpan = [TimeSpan]::FromSeconds($scaledSeconds)
            return "{0:D2}:{1:D2}:{2:D2},{3:D3}" -f $scaledTimeSpan.Hours, $scaledTimeSpan.Minutes, $scaledTimeSpan.Seconds, $scaledTimeSpan.Milliseconds
        }
        return $timestamp
    }
    
    $processedContent = [regex]::Replace($subtitlesContent, $lastTimestampPattern, {
        param($match)
        $scaledStart = Scale-Timestamp $match.Groups[0].Value.Split(' ')[0]
        $scaledEnd = Scale-Timestamp $match.Groups[0].Value.Split(' ')[2]
        return "$scaledStart --> $scaledEnd"
    })
    
    # Backup and save
    Copy-Item $subtitlesPath "$subtitlesPath.backup" -Force
    $processedContent | Set-Content $subtitlesPath -Encoding UTF8 -NoNewline
    Write-Host "[SUCCESS] Subtitles synchronized and saved!"
    
} catch {
    Write-Host "[ERROR] PowerShell error: $($_.Exception.Message)"
    exit 1
}
