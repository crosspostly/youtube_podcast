
# PowerShell script to create video with Ken Burns effect
# FIX: Escape '$' in template literals to prevent TypeScript from interpreting them.
$ErrorActionPreference = "Stop"

try {
    $basePath = (Get-Location).Path
    Write-Host "[INFO] Working directory: $basePath"
    
    $images = Get-ChildItem -Path (Join-Path $basePath "images") -Include *.png,*.jpg,*.jpeg -Recurse | Sort-Object Name
    if ($images.Count -eq 0) { Write-Host "[ERROR] No images found!"; exit 1 }
    
    $audioFile = Join-Path $basePath "final_audio.wav"
    $audioDurationStr = (& ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $audioFile).Trim()
    $audioDuration = [double]::Parse($audioDurationStr, [System.Globalization.CultureInfo]::InvariantCulture)
    
    $durationPerImage = [math]::Round($audioDuration / $images.Count, 3)
    $fps = 25
    
    $ffmpegInputs = @()
    foreach ($img in $images) {
        $ffmpegInputs += "-loop", "1", "-framerate", $fps, "-t", $durationPerImage.ToString([System.Globalization.CultureInfo]::InvariantCulture), "-i", $img.FullName
    }
    
    $filterParts = @()
    $totalFramesPerImage = [int]($durationPerImage * $fps)
    
    for ($i = 0; $i -lt $images.Count; $i++) {
        $inputLabel = "[$($i):v]"
        $outputLabel = "[f$($i)]"
        $zoomSpeed = 0.0012
        $maxZoom = 1.25
        $zoomSpeedStr = $zoomSpeed.ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $maxZoomStr = $maxZoom.ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $kenBurnsFilter = "scale=1920:1080:force_original_aspect_ratio=increase,crop=1280:720,zoompan=z='min(zoom+$zoomSpeedStr,$maxZoomStr)':d=$totalFramesPerImage:s=1280x720"
        $filterParts += "$inputLabel$kenBurnsFilter$outputLabel"
    }
    
    $concatInputLabels = ""
    for ($i = 0; $i -lt $images.Count; $i++) { $concatInputLabels += "[f$($i)]" }
    $concatFilter = $concatInputLabels + "concat=n=" + $images.Count + ":v=1:a=0[v1]"
    
    $subtitlesPath = (Join-Path $basePath "subtitles.srt").Replace('\', '/')
    $subtitlesPathEscaped = $subtitlesPath -replace ':', '\:'
    $subtitlesFilter = "[v1]subtitles='$subtitlesPathEscaped':force_style='FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,MarginV=30,Alignment=2'[v]"
    
    $filterComplex = ($filterParts + $concatFilter + $subtitlesFilter) -join ";"
    
    $audioInputIndex = $images.Count
    
    $videoTitle = (& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $basePath "get_video_title.ps1")).Trim()
    $outputFile = ($videoTitle -replace '[<>:"/\\|?*]', '_').Trim('.', ' ', '_') + ".mp4"
    if ($outputFile.Length -gt 200) { $outputFile = $outputFile.Substring(0, 200) + ".mp4" }
    
    $ffmpegArgs = @("-y") + $ffmpegInputs + @("-filter_complex", $filterComplex, "-i", $audioFile, "-map", "[v]", "-map", "$($audioInputIndex):a:0", "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-c:a", "aac", "-b:a", "192k", "-pix_fmt", "yuv420p", "-shortest", $outputFile)
    
    Write-Host "[INFO] Running FFmpeg to create '$outputFile'..."
    & ffmpeg @ffmpegArgs
    
    if ($LASTEXITCODE -ne 0) { Write-Host "[ERROR] FFmpeg failed!"; exit 1 }
    Write-Host "[SUCCESS] Video created successfully: $outputFile"

} catch {
    Write-Host "[ERROR] PowerShell error: $($_.Exception.Message)"
    exit 1
}
