
# How to Assemble Your Video

This project contains all the necessary files to assemble your final video locally. This gives you more control and allows for higher quality rendering.

## 1. Requirements

- **FFmpeg**: A powerful command-line tool for handling video and audio.
- **PowerShell** (for Windows users): Included by default in modern Windows.
- **Python 3** (optional, but recommended): For the cross-platform 'assemble_locally.py' script.

### Installation

- **Windows**: 'winget install ffmpeg'
- **Mac**: 'brew install ffmpeg'
- **Linux**: 'sudo apt install ffmpeg'

## 2. How to Run

### Recommended Method (All Platforms): Python Script

The Python script ('assemble_locally.py') is the most robust method. It automatically downloads any missing music/SFX files that failed in the browser.

1.  Make sure you have Python 3 installed.
2.  Open your terminal or command prompt in this folder.
3.  Run the script:
    'python assemble_locally.py'

### Windows-Only: Batch Script

If you don't have Python, you can use the '.bat' file on Windows.

1.  Simply double-click 'assemble_video.bat'.
2.  Follow the on-screen instructions.

## 3. What Happens

The script will automatically:
- ✅ **Check for dependencies** like FFmpeg.
- ✅ **Synchronize subtitles** to match the exact audio length.
- ✅ **Combine** the animated images into a video stream.
- ✅ **Add the final audio track** ('final_audio.wav').
- ✅ **Burn in the subtitles** directly onto the video.
- ✅ **Name the final file** based on your 'VIDEO_TITLE.txt'.

The output will be a high-quality MP4 file, ready for upload.
