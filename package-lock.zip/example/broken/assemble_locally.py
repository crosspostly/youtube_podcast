
import os
import subprocess
import glob
import urllib.request
import re

def download_missing_assets():
    print("--- Checking for missing assets (Music/SFX) ---")
    for folder in ['music', 'sfx']:
        if not os.path.exists(folder): continue
        for txt_file in glob.glob(os.path.join(folder, "[LINK]*.txt")):
            try:
                print(f"Found placeholder: {txt_file}")
                with open(txt_file, 'r', encoding='utf-8', errors='ignore') as f:
                    url = next((line.split("Source URL:", 1)[1].strip() for line in f if "Source URL:" in line), None)
                if url:
                    base_name = os.path.basename(txt_file)
                    clean_name = base_name.replace("[LINK]_", "").rsplit('.', 1)[0] + ".mp3"
                    dest_path = os.path.join(folder, clean_name)
                    print(f"Downloading: {url} -> {clean_name} ...")
                    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req) as response, open(dest_path, 'wb') as out_file:
                        out_file.write(response.read())
                    print("Download successful.")
                    os.remove(txt_file)
            except Exception as e:
                print(f"Failed to download asset from {txt_file}: {e}")
    print("--- Asset check complete ---\n")

def get_video_title():
    if os.path.exists("VIDEO_TITLE.txt"):
        with open("VIDEO_TITLE.txt", "r", encoding='utf-8') as f:
            return f.read().strip()
    if os.path.exists("youtube_details.txt"):
        with open("youtube_details.txt", "r", encoding='utf-8') as f:
            match = re.search(r"TITLE:\s*([\s\S]*?)(?:\n----|$)", f.read(), re.MULTILINE)
            if match: return match.group(1).strip()
    return "final_video"

def create_video():
    download_missing_assets()
    
    images = sorted(glob.glob("images/*.png") + glob.glob("images/*.jpg") + glob.glob("images/*.jpeg"))
    if not images:
        print("[ERROR] No images found in images/ folder.")
        return

    try:
        result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', 'final_audio.wav'], capture_output=True, text=True, check=True)
        audio_duration = float(result.stdout)
        duration_per_image = round(audio_duration / len(images), 3)
    except (subprocess.CalledProcessError, FileNotFoundError, ValueError) as e:
        print(f"[ERROR] Could not get audio duration from final_audio.wav: {e}")
        return

    video_title = get_video_title()
    sanitized_title = re.sub(r'[<>:"/\\|?*]', '_', video_title).strip('. _')[:200]
    output_file = f"{sanitized_title}.mp4"

    ffmpeg_inputs = []
    for img in images:
        ffmpeg_inputs.extend(['-loop', '1', '-framerate', '25', '-t', str(duration_per_image), '-i', img])

    filter_complex_parts = []
    for i in range(len(images)):
        filter_complex_parts.append(f"[{i}:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1280:720,zoompan=z='min(zoom+0.0012,1.25)':d={int(duration_per_image * 25)}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1280x720[f{i}]")

    concat_inputs = "".join([f"[f{i}]" for i in range(len(images))])
    concat_filter = f"{concat_inputs}concat=n={len(images)}:v=1:a=0[v1]"
    
    subtitles_filter = f"[v1]subtitles=subtitles.srt:force_style='FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,MarginV=30,Alignment=2'[v]"
    
    filter_complex = ";".join(filter_complex_parts + [concat_filter, subtitles_filter])
    
    cmd = ['ffmpeg', '-y'] + ffmpeg_inputs + [
        '-filter_complex', filter_complex,
        '-i', 'final_audio.wav',
        '-map', '[v]', '-map', f'{len(images)}:a:0',
        '-c:v', 'libx264', '-preset', 'slow', '-crf', '18',
        '-c:a', 'aac', '-b:a', '192k',
        '-pix_fmt', 'yuv420p', '-shortest', output_file
    ]
    
    print(f"Running FFmpeg to create '{output_file}'...")
    try:
        subprocess.run(cmd, check=True)
        print(f"\n[SUCCESS] Video created: {output_file}")
    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] FFmpeg failed: {e}")
    except FileNotFoundError:
        print("\n[ERROR] FFmpeg not found. Please install FFmpeg and add it to your system's PATH.")

if __name__ == '__main__':
    create_video()
