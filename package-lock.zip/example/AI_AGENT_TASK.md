# Задание для ИИ агента: Создание системы сборки видео с динамическими эффектами

## Цель задачи

Создать систему автоматической сборки видео из изображений, аудио и субтитров с:
- ✅ Автоматической синхронизацией субтитров
- ✅ Плавной сменой изображений
- ✅ Динамическими эффектами (Ken Burns эффект) для изображений
- ✅ Правильным именованием выходного файла по названию видео
- ✅ Рабочими бат-файлами для Windows

---

## КРИТИЧЕСКИ ВАЖНО: Как создавать РАБОЧИЕ бат-файлы

### ❌ ЧАСТЫЕ ОШИБКИ (чего НЕ делать):

1. **НЕ создавайте слишком сложные inline PowerShell команды в бат-файлах**
   ```batch
   ❌ ПЛОХО:
   powershell -Command "& { очень длинная команда с множеством экранирований }"
   ```

2. **НЕ смешивайте логику обработки данных с основным бат-файлом**
   ```batch
   ❌ ПЛОХО: Бат-файл пытается сам вычислять длительность аудио через сложные циклы
   ```

3. **НЕ игнорируйте обработку ошибок**
   ```batch
   ❌ ПЛОХО:
   ffmpeg -i input output
   echo Done
   ```

### ✅ ПРАВИЛЬНЫЙ ПОДХОД:

1. **Создавайте ОТДЕЛЬНЫЕ PowerShell скрипты для сложной логики**
   ```batch
   ✅ ХОРОШО:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "create_video.ps1"
   ```

2. **Используйте бат-файл только для оркестрации и проверок**
   ```batch
   ✅ ХОРОШО:
   @echo off
   REM Проверки
   if not exist "file.wav" (echo ERROR & pause & exit /b 1)
   REM Вызов скриптов
   powershell.exe -File "script.ps1"
   REM Проверка результата
   if %errorlevel% neq 0 (echo FAILED & pause & exit /b 1)
   ```

3. **Всегда проверяйте наличие файлов и зависимостей**
   ```batch
   ✅ ХОРОШО:
   where ffmpeg >nul 2>nul
   if %errorlevel% neq 0 (
       echo [ERROR] FFmpeg not found!
       pause
       exit /b 1
   )
   ```

---

## Структура проекта (что должно быть создано)

```
project_folder/
├── assemble_video.bat          # Главный бат-файл (простой, только оркестрация)
│
├── create_video.ps1            # Основная логика создания видео
├── create_filelist.ps1         # Создание списка файлов (если нужно)
├── sync_subtitles.ps1          # Синхронизация субтитров с аудио
├── get_video_title.ps1         # Получение названия видео
│
├── VIDEO_TITLE.txt             # Название видео (обязательный файл)
├── final_audio.wav             # Аудио файл
├── subtitles.srt               # Файл субтитров
└── images/                     # Папка с изображениями
    ├── img_001.png
    ├── img_002.png
    └── img_003.png
```

---

## Требования к функциональности

### 1. Основной бат-файл (assemble_video.bat)

**Должен:**
- ✅ Проверять наличие всех необходимых файлов (final_audio.wav, subtitles.srt, images/)
- ✅ Проверять наличие FFmpeg и PowerShell
- ✅ Вызывать sync_subtitles.ps1 для синхронизации субтитров
- ✅ Вызывать create_video.ps1 для создания видео
- ✅ Показывать информативные сообщения на каждом этапе
- ✅ Обрабатывать ошибки и останавливаться при проблемах
- ✅ Использовать `pause` в конце для просмотра результатов

**Пример структуры:**
```batch
@echo off
setlocal enabledelayedexpansion

echo ===================================================
echo   Video Assembler
echo ===================================================
echo.

REM 1. Проверки
if not exist "final_audio.wav" (
    echo [ERROR] final_audio.wav not found!
    pause
    exit /b 1
)

REM 2. Проверка зависимостей
where ffmpeg >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] FFmpeg not found!
    pause
    exit /b 1
)

REM 3. Синхронизация субтитров
echo [INFO] Synchronizing subtitles...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "sync_subtitles.ps1"
if %errorlevel% neq 0 (
    echo [WARNING] Subtitle sync failed, continuing...
)

REM 4. Создание видео
echo [INFO] Creating video...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "create_video.ps1"
if %errorlevel% neq 0 (
    echo [ERROR] Video creation failed!
    pause
    exit /b 1
)

echo [SUCCESS] Video created!
pause
```

### 2. Скрипт создания видео (create_video.ps1)

**Должен:**
- ✅ Находить все изображения в папке images/
- ✅ Получать длительность аудио через ffprobe
- ✅ Распределять время между изображениями пропорционально
- ✅ Применять эффект Ken Burns (zoom + pan) к каждому изображению
- ✅ Объединять все изображения в одно видео
- ✅ Применять субтитры
- ✅ Использовать название из VIDEO_TITLE.txt для имени файла
- ✅ Правильно обрабатывать пути в Windows (экранирование, пробелы)

**Ключевые моменты для FFmpeg:**

1. **Эффект Ken Burns** (медленное приближение с панорамированием):
   ```ffmpeg
   zoompan=z='if(lte(zoom,1.0),1.5,max(1.001,zoom-0.0015))':d=125*25:s=1280x720
   ```
   - `z='...'` - формула zoom (начинается с 1.0, постепенно увеличивается до 1.5)
   - `d=125*25` - длительность в кадрах (125 секунд * 25 fps)
   - `s=1280x720` - размер выхода

2. **Альтернатива - простое панорамирование**:
   ```ffmpeg
   crop=1280:720:iw/3:ih/3,scale=1280:720
   ```

3. **Правильное создание filter_complex**:
   - Каждое изображение обрабатывается отдельно
   - Все обработанные изображения объединяются через concat
   - Субтитры применяются к объединенному видео

**Пример структуры create_video.ps1:**
```powershell
# 1. Получить все изображения
$images = Get-ChildItem -Path "images" -Include *.png,*.jpg,*.jpeg -Recurse | Sort-Object Name

# 2. Получить длительность аудио
$audioDuration = [double](ffprobe -v error -show_entries format=duration ...)

# 3. Вычислить длительность на изображение
$durationPerImage = $audioDuration / $images.Count

# 4. Создать входы для FFmpeg (loop + framerate + duration для каждого изображения)
$ffmpegInputs = @()
foreach ($img in $images) {
    $ffmpegInputs += "-loop", "1", "-framerate", "25", "-t", $durationPerImage, "-i", $img.FullName
}

# 5. Создать filter_complex с эффектом Ken Burns
$filterParts = @()
for ($i = 0; $i -lt $images.Count; $i++) {
    # Ken Burns эффект: медленное приближение
    $frames = [int]($durationPerImage * 25)
    $filterParts += "[$i`:v]scale=1920:1080:force_original_aspect_ratio=increase,zoompan=z='min(zoom+0.0015,1.5)':d=$frames`:s=1280x720[f$i]"
}

# 6. Объединить все изображения
$concatInputs = ""
for ($i = 0; $i -lt $images.Count; $i++) {
    $concatInputs += "[f$i]"
}
$concatFilter = "${concatInputs}concat=n=$($images.Count):v=1:a=0[v1]"

# 7. Применить субтитры
$subtitlesPath = (Join-Path $basePath "subtitles.srt").Replace('\', '/').Replace(':', '\:')
$subtitlesFilter = "[v1]subtitles='$subtitlesPath':...'[v]"

# 8. Объединить все фильтры
$filterComplex = ($filterParts + $concatFilter + $subtitlesFilter) -join ";"

# 9. Получить название видео
$videoTitle = (Get-Content "VIDEO_TITLE.txt" -Raw).Trim()
$videoTitle = $videoTitle -replace '[<>:"/\\|?*]', '_'  # Очистить от недопустимых символов
$outputFile = "$videoTitle.mp4"

# 10. Запустить FFmpeg
ffmpeg -y @ffmpegInputs -filter_complex $filterComplex -map "[v]" -i $audioFile -map "$audioIndex`:a:0" ... $outputFile
```

### 3. Скрипт синхронизации субтитров (sync_subtitles.ps1)

**Должен:**
- ✅ Получать длительность аудио через ffprobe
- ✅ Находить последнюю временную метку в subtitles.srt
- ✅ Вычислять коэффициент масштабирования
- ✅ Применять масштабирование ко всем временным меткам
- ✅ Создавать резервную копию оригинального файла
- ✅ Сохранять результат в UTF-8 (для правильной кодировки символов)

**Алгоритм:**
1. Читать последнюю временную метку из SRT (формат: `00:05:40,000 --> 00:05:43,000`)
2. Конвертировать в секунды: `hours*3600 + minutes*60 + seconds + milliseconds/1000`
3. Вычислить коэффициент: `audioDuration / lastSubtitleTime`
4. Применить коэффициент ко всем временным меткам
5. Конвертировать обратно в формат SRT

### 4. Скрипт получения названия (get_video_title.ps1)

**Должен:**
- ✅ Сначала читать VIDEO_TITLE.txt
- ✅ Если нет, читать из youtube_details.txt (раздел TITLE:)
- ✅ Fallback на "final_video" если ничего не найдено
- ✅ Возвращать только текст (без лишних символов)

---

## Технические детали для FFmpeg

### Ken Burns эффект (медленное приближение)

**Вариант 1: Медленный zoom in (приближение)**
```ffmpeg
zoompan=z='min(zoom+0.0015,1.5)':d=125*25:s=1280x720
```
- Начинается с zoom=1.0 (нормальный размер)
- Постепенно увеличивается до 1.5x (50% увеличение)
- `0.0015` - скорость приближения (можно менять: меньше = медленнее)

**Вариант 2: Медленный zoom out (отдаление)**
```ffmpeg
zoompan=z='max(zoom-0.0015,1.0)':d=125*25:s=1280x720:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'
```
- Начинается с zoom=1.5
- Постепенно уменьшается до 1.0

**Вариант 3: Панорамирование влево**
```ffmpeg
crop=1280:720:0*on/300:0,scale=1280:720
```

**Вариант 4: Комбинация zoom + pan**
```ffmpeg
zoompan=z='min(zoom+0.001,1.3)':d=125*25:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1280x720
```

### Важно для обработки путей в Windows:

1. **Экранирование двоеточий в путях**:
   ```powershell
   $path = $path.Replace(':', '\:')  # Для filter_complex в FFmpeg
   ```

2. **Замена обратных слешей**:
   ```powershell
   $path = $path.Replace('\', '/')  # FFmpeg предпочитает /
   ```

3. **Обработка пробелов**:
   ```powershell
   $path = "'$path'"  # Заключить в кавычки
   ```

---

## Алгоритм создания видео (пошагово)

1. **Подготовка**:
   - Проверить наличие всех файлов
   - Получить список изображений из `images/`
   - Отсортировать изображения по имени

2. **Синхронизация субтитров**:
   - Получить длительность аудио
   - Найти последнюю временную метку в SRT
   - Растянуть все временные метки пропорционально

3. **Расчет длительности**:
   - Получить длительность аудио через ffprobe
   - Разделить на количество изображений
   - Каждое изображение будет показываться равное время

4. **Создание фильтров**:
   - Для каждого изображения: loop + framerate + duration
   - Применить Ken Burns эффект (zoompan)
   - Объединить через concat
   - Применить субтитры

5. **Сборка команды FFmpeg**:
   ```
   ffmpeg -y
     -loop 1 -framerate 25 -t 125.35 -i image1.png
     -loop 1 -framerate 25 -t 125.35 -i image2.png
     ...
     -filter_complex "[0:v]zoompan=... [f0]; [1:v]zoompan=... [f1]; ... [f0][f1]concat=... [v1]; [v1]subtitles=... [v]"
     -map "[v]"
     -i final_audio.wav
     -map "3:a:0"  # Индекс аудио = количество изображений
     -c:v libx264 -preset slow -crf 18
     -c:a aac -b:a 192k
     -pix_fmt yuv420p
     -shortest
     "Video Title.mp4"
   ```

6. **Обработка ошибок**:
   - Проверять exit code после каждого шага
   - Выводить понятные сообщения об ошибках
   - Останавливаться при критических ошибках

---

## Чеклист для проверки работоспособности

- [ ] Бат-файл проверяет наличие всех необходимых файлов
- [ ] Бат-файл проверяет наличие FFmpeg и PowerShell
- [ ] PowerShell скрипты используют правильную обработку ошибок (`try-catch`)
- [ ] Все пути правильно обрабатываются (пробелы, специальные символы)
- [ ] Субтитры синхронизируются автоматически
- [ ] Эффект Ken Burns применяется к каждому изображению
- [ ] Название видео берется из VIDEO_TITLE.txt
- [ ] Выходной файл имеет правильное имя (без недопустимых символов)
- [ ] Все скрипты работают независимо (можно запускать отдельно)
- [ ] Вывод информативен и понятен пользователю

---

## Важные принципы

1. **Разделение ответственности**:
   - Бат-файл = только оркестрация и проверки
   - PowerShell скрипты = вся логика и обработка данных

2. **Обработка ошибок**:
   - Всегда проверять exit codes
   - Выводить понятные сообщения
   - Останавливаться при критических ошибках

3. **Кросс-платформенность**:
   - Использовать стандартные инструменты (FFmpeg, PowerShell)
   - Избегать Windows-специфичных команд где возможно

4. **Производительность**:
   - Использовать `-preset slow` для качества
   - Использовать `-crf 18` для хорошего качества/размера
   - Использовать `-shortest` для синхронизации с аудио

---

## Примеры кода (готовые фрагменты)

### Получение длительности аудио:
```powershell
$audioDuration = [double](& ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "final_audio.wav")
```

### Очистка названия для имени файла:
```powershell
$videoTitle = $videoTitle -replace '[<>:"/\\|?*]', '_'
$videoTitle = $videoTitle.Trim('.', ' ', '_')
```

### Создание Ken Burns эффекта:
```powershell
$frames = [int]($durationPerImage * 25)  # FPS = 25
$zoomFilter = "[$i`:v]scale=1920:1080:force_original_aspect_ratio=increase,zoompan=z='min(zoom+0.0015,1.5)':d=$frames`:s=1280x720[f$i]"
```

### Правильная сборка filter_complex:
```powershell
$allFilters = $filterParts + $concatFilter + $subtitlesFilter
$filterComplex = $allFilters -join ";"
```

---

## Тестирование

После создания системы протестировать:
1. ✅ Запуск с минимальными данными (1 изображение, короткий аудио)
2. ✅ Запуск с максимальными данными (много изображений, длинный аудио)
3. ✅ Обработка ошибок (отсутствующие файлы, неправильные пути)
4. ✅ Синхронизация субтитров (короткие/длинные субтитры)
5. ✅ Именование файлов (специальные символы в названии)

---

**КРИТИЧЕСКИ ВАЖНО**: Создавайте простые, понятные, модульные решения. Если код становится сложным - выносите в отдельные скрипты. Всегда тестируйте на реальных данных!

