# PowerShell script to create video from images with proper timing
$ErrorActionPreference = "Continue"

try {
    $basePath = (Get-Location).Path
    Write-Host "[INFO] Working directory: $basePath"
    
    # Find all images
    $imagesPath = Join-Path $basePath "images"
    $images = @()
    $images += Get-ChildItem -Path $imagesPath -Filter *.png -Recurse -ErrorAction SilentlyContinue
    $images += Get-ChildItem -Path $imagesPath -Filter *.jpg -Recurse -ErrorAction SilentlyContinue
    $images += Get-ChildItem -Path $imagesPath -Filter *.jpeg -Recurse -ErrorAction SilentlyContinue
    $images = $images | Sort-Object -Property Name
    
    if ($images.Count -eq 0) {
        Write-Host "[ERROR] No images found!"
        exit 1
    }
    
    Write-Host "[INFO] Found $($images.Count) image(s)"
    
    # Get audio duration
    $audioFile = Join-Path $basePath "final_audio.wav"
    $audioDuration = [double](& ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $audioFile)
    $durationPerImage = [math]::Round($audioDuration / $images.Count, 2)
    $fps = 25
    
    Write-Host "[INFO] Audio duration: $audioDuration seconds"
    Write-Host "[INFO] Duration per image: $durationPerImage seconds"
    Write-Host "[INFO] Creating FFmpeg command..."
    
    # Build FFmpeg inputs for each image
    $ffmpegInputs = @()
    for ($i = 0; $i -lt $images.Count; $i++) {
        $img = $images[$i]
        $ffmpegInputs += "-loop"
        $ffmpegInputs += "1"
        $ffmpegInputs += "-framerate"
        $ffmpegInputs += $fps
        $ffmpegInputs += "-t"
        # Use InvariantCulture to ensure dot as decimal separator for FFmpeg
        $ffmpegInputs += $durationPerImage.ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $ffmpegInputs += "-i"
        $ffmpegInputs += $img.FullName
    }
    
    # Build filter_complex with Ken Burns effect (zoom and pan) for each image
    # Each image input will be [0:v], [1:v], [2:v], etc.
    $filterParts = @()
    $fpsInt = [int]$fps
    $totalFramesPerImage = [int]($durationPerImage * $fps)
    
    for ($i = 0; $i -lt $images.Count; $i++) {
        # Use string formatting to properly escape brackets
        $inputLabel = "[" + $i + ":v]"
        $outputLabel = "[f" + $i + "]"
        
        # Ken Burns effect: Ненавязчивое медленное приближение (zoom in)
        # Настройки эффекта (можно менять для разных стилей):
        $zoomSpeed = 0.0012  # Скорость приближения (0.0008 = очень медленно, 0.002 = быстрее)
        $maxZoom = 1.25      # Максимальное увеличение (1.2 = 20%, 1.3 = 30%, 1.4 = 40%)
                             # Рекомендуется 1.25 (25%) для ненавязчивого эффекта
        
        # Формула: zoompan постепенно увеличивает масштаб с 1.0 до maxZoom
        # x, y: центрирование кадра (панорамирование к центру изображения)
        # d: длительность в кадрах
        # s: размер выхода
        
        # Сначала увеличиваем изображение для возможности зума (1920x1080)
        # Затем применяем zoompan для плавного приближения
        # zoompan: z='min(zoom+0.0012,1.25)' - медленное приближение с 1.0 до 1.25 (25% zoom)
        $zoomSpeedStr = $zoomSpeed.ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $maxZoomStr = $maxZoom.ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $kenBurnsFilter = "scale=1920:1080:force_original_aspect_ratio=increase,zoompan=z='min(zoom+$zoomSpeedStr',$maxZoomStr)':d=$totalFramesPerImage`:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1280x720"
        
        $filterParts += $inputLabel + $kenBurnsFilter + $outputLabel
    }
    
    # Add fade transitions between images for smooth transitions
    $fadeParts = @()
    $fadeDuration = 0.5  # 0.5 seconds fade
    
    for ($i = 0; $i -lt $images.Count; $i++) {
        $fadeInput = "[f" + $i + "]"
        $fadeOutput = "[f" + $i + "f]"
        
        if ($i -eq 0) {
            # First image: fade in at start
            $fadeFrames = [int]($fadeDuration * $fps)
            $fadeParts += $fadeInput + "fade=t=in:st=0:d=" + $fadeDuration.ToString([System.Globalization.CultureInfo]::InvariantCulture) + $fadeOutput
        } elseif ($i -eq $images.Count - 1) {
            # Last image: fade out at end
            $fadeEnd = $durationPerImage - $fadeDuration
            $fadeParts += $fadeInput + "fade=t=out:st=" + $fadeEnd.ToString([System.Globalization.CultureInfo]::InvariantCulture) + ":d=" + $fadeDuration.ToString([System.Globalization.CultureInfo]::InvariantCulture) + $fadeOutput
        } else {
            # Middle images: fade in and out
            $fadeEnd = $durationPerImage - $fadeDuration
            $fadeParts += $fadeInput + "fade=t=in:st=0:d=" + $fadeDuration.ToString([System.Globalization.CultureInfo]::InvariantCulture) + ",fade=t=out:st=" + $fadeEnd.ToString([System.Globalization.CultureInfo]::InvariantCulture) + ":d=" + $fadeDuration.ToString([System.Globalization.CultureInfo]::InvariantCulture) + $fadeOutput
        }
    }
    
    # Concat all images with fades
    $concatInputLabels = ""
    for ($i = 0; $i -lt $images.Count; $i++) {
        $concatInputLabels += "[f" + $i + "f]"
    }
    $concatFilter = $concatInputLabels + "concat=n=" + $images.Count + ":v=1:a=0[v1]"
    
    # Apply subtitles to concatenated video
    $subtitlesPath = Join-Path $basePath "subtitles.srt"
    # Escape path for FFmpeg (Windows paths need special handling)
    $subtitlesPathEscaped = $subtitlesPath.Replace('\', '/')
    # Escape colon in Windows path (C:/ -> C\:/)
    if ($subtitlesPathEscaped -match '^([A-Z]):') {
        $driveLetter = $Matches[1]
        $subtitlesPathEscaped = $subtitlesPathEscaped -replace "^${driveLetter}:", "${driveLetter}\:"
    }
    $subtitlesFilter = "[v1]subtitles='$subtitlesPathEscaped':force_style='FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,MarginV=30,Alignment=2'[v]"
    
    # Combine all filters: Ken Burns effects -> fades -> concat -> subtitles
    $allFilters = $filterParts + $fadeParts + $concatFilter + $subtitlesFilter
    $filterComplex = $allFilters -join ";"
    
    Write-Host "[INFO] Starting FFmpeg with filter_complex..."
    Write-Host "[DEBUG] Filter complex: $filterComplex"
    Write-Host "[DEBUG] Filter complex length: $($filterComplex.Length) characters"
    
    # Build final FFmpeg command
    # Order: inputs for images, filter_complex, audio input, maps, encoding options
    $audioInputIndex = $images.Count  # Audio will be at this index after all image inputs
    
    $ffmpegArgs = @(
        "-y"
    )
    # Add all image inputs
    $ffmpegArgs += $ffmpegInputs
    # Add filter_complex
    $ffmpegArgs += @(
        "-filter_complex", $filterComplex
    )
    # Add audio input
    $ffmpegArgs += @(
        "-i", $audioFile
    )
    # Map video and audio
    $ffmpegArgs += @(
        "-map", "[v]"
        "-map", "$audioInputIndex`:a:0"
    )
    # Get video title for output filename
    $titleScript = Join-Path $basePath "get_video_title.ps1"
    $videoTitle = "final_video"
    if (Test-Path $titleScript) {
        try {
            $titleResult = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $titleScript 2>$null
            if ($titleResult) {
                $videoTitle = ($titleResult -join "").Trim()
                # Clean title for filename (remove invalid characters)
                $videoTitle = $videoTitle -replace '[<>:"/\\|?*]', '_'
                $videoTitle = $videoTitle -replace '\.\s*\.', '_'  # Replace consecutive dots
                $videoTitle = $videoTitle.Trim('.', ' ', '_')
                # Limit length
                if ($videoTitle.Length -gt 200) {
                    $videoTitle = $videoTitle.Substring(0, 200)
                }
            }
        } catch {
            Write-Host "[WARNING] Could not get video title, using default"
        }
    }
    
    $outputFile = "$videoTitle.mp4"
    Write-Host "[INFO] Output file: $outputFile"
    
    # Encoding options
    $ffmpegArgs += @(
        "-c:v", "libx264"
        "-preset", "slow"
        "-crf", "18"
        "-c:a", "aac"
        "-b:a", "192k"
        "-pix_fmt", "yuv420p"
        "-shortest"
        $outputFile
    )
    
    Write-Host "[INFO] Running FFmpeg..."
    Write-Host "[DEBUG] Audio input index: $audioInputIndex"
    
    & ffmpeg @ffmpegArgs
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[SUCCESS] Video created successfully: $outputFile"
    } else {
        Write-Host "[ERROR] FFmpeg failed with exit code: $LASTEXITCODE"
        exit 1
    }
    
} catch {
    Write-Host "[ERROR] PowerShell error: $_"
    Write-Host "Error details: $($_.Exception.Message)"
    exit 1
}

