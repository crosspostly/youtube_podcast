import React, { useState, useMemo } from 'react';
import JSZip from 'jszip';
import { combineAndMixAudio, convertWavToMp3, generateSrtFile } from '../../services/audioUtils';
import { fetchWithCorsFallback } from '../../services/apiUtils';
import { ASSEMBLE_VIDEO_BAT, GET_VIDEO_TITLE_PS1, SYNC_SUBTITLES_PS1, CREATE_VIDEO_PS1, UPDATED_README_ASSEMBLY } from './scriptTemplates';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
const AUTO_DOWNLOAD_ASSETS_PS1 = require('./auto_download_assets.ps1?raw');
import type { Podcast, LogEntry } from '../../types';

type LogFunction = (entry: Omit<LogEntry, 'timestamp'>) => void;

/**
 * Safely download a file with retry logic and timeout
 * Returns the blob if successful, or null if failed
 */
const downloadFileWithRetry = async (
    url: string,
    fileType: 'music' | 'sfx',
    log: LogFunction,
    maxRetries: number = 2,
    timeoutMs: number = 15000
): Promise<Blob | null> => {
    let lastError: any;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            // Create abort controller with timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
            
            const response = await fetchWithCorsFallback(url, {
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            clearTimeout(timeoutId);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const blob = await response.blob();
            if (!blob || blob.size === 0) {
                throw new Error('Empty response');
            }
            
            return blob;
        } catch (e: any) {
            lastError = e;
            const errorMsg = e?.message || String(e);
            const isCorsError = errorMsg.includes('CORS') || errorMsg.includes('origin');
            
            if (attempt < maxRetries && !isCorsError) {
                log({
                    type: 'info',
                    message: `Попытка ${attempt}/${maxRetries} скачать ${fileType} не удалась. Повторяю...`,
                    data: { error: errorMsg }
                });
                // Exponential backoff: 1s, 2s
                await new Promise(r => setTimeout(r, Math.pow(2, attempt - 1) * 1000));
            } else if (isCorsError) {
                // CORS error - no point retrying, will use link fallback
                log({
                    type: 'info',
                    message: `Ошибка CORS при скачивании ${fileType}. Будет сохранена ссылка для скачивания на ПК.`,
                    data: { error: errorMsg }
                });
                return null;
            }
        }
    }
    
    log({
        type: 'error',
        message: `Не удалось скачать ${fileType} после ${maxRetries} попыток. Сохраняю ссылку.`,
        data: { url, lastError: lastError?.message }
    });
    return null;
};

export const useExport = (
    podcast: Podcast | null,
    log: LogFunction,
    setError: React.Dispatch<React.SetStateAction<string | null>>,
    devMode: boolean
) => {
    const [isCombiningAudio, setIsCombiningAudio] = useState(false);
    const [isGeneratingSrt, setIsGeneratingSrt] = useState(false);
    const [isZipping, setIsZipping] = useState(false);

    const combineAndDownload = async (format: 'wav' | 'mp3' = 'wav') => {
        if (!podcast || podcast.chapters.some(c => c.status !== 'completed' || !c.audioBlob)) return;
        
        setIsCombiningAudio(true);
        try {
            let finalBlob = await combineAndMixAudio(podcast);
            let extension = 'wav';
            if (format === 'mp3') {
                finalBlob = await convertWavToMp3(finalBlob, log);
                extension = 'mp3';
            }
            const url = URL.createObjectURL(finalBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${podcast.selectedTitle.replace(/[^a-z0-9а-яё]/gi, '_').toLowerCase()}.${extension}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (err: any) {
            setError('Ошибка при сборке аудиофайла.');
            log({type: 'error', message: `Ошибка при сборке и экспорте (${format})`, data: err});
        } finally {
            setIsCombiningAudio(false);
        }
    };

    const generateSrt = async () => {
        if (!podcast) return;
        setIsGeneratingSrt(true);
        try {
            const srtBlob = await generateSrtFile(podcast, log);
            const url = URL.createObjectURL(srtBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${podcast.selectedTitle.replace(/[^a-z0-9а-яё]/gi, '_').toLowerCase()}.srt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (err: any) {
            setError('Ошибка при создании SRT файла.');
            log({type: 'error', message: 'Ошибка при генерации SRT', data: err});
        } finally {
            setIsGeneratingSrt(false);
        }
    };

    const downloadProjectAsZip = async () => {
        if (!podcast || !podcast.chapters.every(c => c.status === 'completed')) {
            log({ type: 'info', message: 'Экспорт ZIP отменен: не все главы имеют статус "completed".' });
            // Optionally, provide more specific user feedback e.g. using a toast notification
            // For now, logging is sufficient to debug.
            return;
        }
        
        setIsZipping(true);
        log({ type: 'info', message: `Начало сборки ZIP-архива для проекта: ${podcast.selectedTitle}` });

        try {
            const zip = new JSZip();
            zip.file('VIDEO_TITLE.txt', podcast.selectedTitle);
            log({ type: 'info', message: 'ZIP: Микширование финального аудио...' });
            const finalAudioWav = await combineAndMixAudio(podcast);
            zip.file('final_audio.wav', finalAudioWav);
            log({ type: 'info', message: 'ZIP: Генерация субтитров...' });
            const srtBlob = await generateSrtFile(podcast, log);
            zip.file('subtitles.srt', srtBlob);

            const [voiceFolder, musicFolder, sfxFolder, imageFolder] = [zip.folder('voice'), zip.folder('music'), zip.folder('sfx'), zip.folder('images')];
            let globalImageCounter = 1;

            for (let i = 0; i < podcast.chapters.length; i++) {
                const chapter = podcast.chapters[i];
                log({ type: 'info', message: `ZIP: Обработка главы ${i + 1}...` });
                if (chapter.audioBlob) voiceFolder?.file(`chapter_${i + 1}_voice.wav`, chapter.audioBlob);
                if (chapter.backgroundMusic) {
                    const safeName = chapter.backgroundMusic.name.replace(/[^a-z0-9]/gi, '_').substring(0, 30);
                    const textContent = `Source URL: ${chapter.backgroundMusic.audio}\nTrack: ${chapter.backgroundMusic.name}\nArtist: ${chapter.backgroundMusic.artist_name}`;
                    
                    if (devMode) {
                        musicFolder?.file(`[LINK]_chapter_${i + 1}_${safeName}.txt`, textContent);
                    } else {
                        const musicUrl = chapter.backgroundMusic.audio.replace(/^http:\/\//, 'https://');
                        const musicBlob = await downloadFileWithRetry(musicUrl, 'music', log, 2, 15000);
                        
                        if (musicBlob) {
                            musicFolder?.file(`chapter_${i + 1}_${safeName}.mp3`, musicBlob);
                            log({ type: 'info', message: `✓ Музыка для главы ${i + 1} успешно скачана` });
                        } else {
                            // Fallback: save link for later download on user's PC
                            musicFolder?.file(`[LINK]_chapter_${i + 1}_${safeName}.txt`, textContent);
                            log({ type: 'info', message: `Музыка для главы ${i + 1} будет скачана позже на ПК` });
                        }
                    }
                }
                if (chapter.script) {
                    for (const line of chapter.script) {
                        if (line.speaker.toUpperCase() === 'SFX' && line.soundEffect?.previews?.['preview-hq-mp3']) {
                            const safeSfxName = line.soundEffect.name.replace(/[^a-z0-9]/gi, '_').substring(0, 30);
                            const hqPreview = line.soundEffect.previews['preview-hq-mp3'];
                            const textContent = `Source URL: ${hqPreview}\nName: ${line.soundEffect.name}\nLicense: ${line.soundEffect.license}\nUsername: ${line.soundEffect.username}`;
                            
                            if (devMode) {
                                sfxFolder?.file(`[LINK]_${safeSfxName}.txt`, textContent);
                            } else {
                                const sfxUrl = hqPreview.replace(/^http:\/\//, 'https://');
                                const sfxBlob = await downloadFileWithRetry(sfxUrl, 'sfx', log, 2, 15000);
                                
                                if (sfxBlob) {
                                    sfxFolder?.file(`${safeSfxName}.mp3`, sfxBlob);
                                    log({ type: 'info', message: `✓ SFX "${line.soundEffect.name}" успешно скачан` });
                                } else {
                                    // Fallback: save link for later download on user's PC
                                    sfxFolder?.file(`[LINK]_${safeSfxName}.txt`, textContent);
                                    log({ type: 'info', message: `SFX "${line.soundEffect.name}" будет скачан позже на ПК` });
                                }
                            }
                        }
                    }
                }
                if (chapter.images) {
                    for (const imgSrc of chapter.images) {
                        try {
                            const response = await fetchWithCorsFallback(imgSrc);
                            if (!response.ok) throw new Error(`Fetch failed: ${response.statusText}`);
                            const blob = await response.blob();
                            const ext = blob.type.split('/')[1] || 'jpeg';
                            const filename = `img_${String(globalImageCounter++).padStart(3, '0')}.${ext}`;
                            imageFolder?.file(filename, blob);
                        } catch (e) {
                            log({ type: 'error', message: `Не удалось скачать картинку. Пропуск.` });
                        }
                    }
                }
            }

            // Add new scripts
            zip.file('sync_subtitles.ps1', SYNC_SUBTITLES_PS1);
            zip.file('get_video_title.ps1', GET_VIDEO_TITLE_PS1);
            zip.file('create_video.ps1', CREATE_VIDEO_PS1);
            zip.file('assemble_video.bat', ASSEMBLE_VIDEO_BAT);
            zip.file('auto_download_assets.ps1', AUTO_DOWNLOAD_ASSETS_PS1);
            zip.file('README_ASSEMBLY.txt', UPDATED_README_ASSEMBLY);

            // TODO: добавить скрипт/инструкцию для автоматической докачки недостающих файлов на ПК перед сборкой видео

            log({ type: 'info', message: 'ZIP: Финальная упаковка архива...' });
            const zipBlob = await zip.generateAsync({ type: 'blob' });
            const url = URL.createObjectURL(zipBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${podcast.selectedTitle.replace(/[^a-z0-9а-яё]/gi, '_').toLowerCase()}_videopack.zip`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

        } catch (err: any) {
            setError('Ошибка при создании ZIP-архива.');
            log({ type: 'error', message: 'Ошибка при сборке ZIP-архива', data: err });
        } finally {
             setIsZipping(false);
        }
    };
    
    const manualTtsScript = useMemo(() => {
        if (!podcast) return 'Генерация сценария...';
        const completedChapters = podcast.chapters.filter(c => c.status === 'completed' && c.script?.length > 0);
        if (completedChapters.length === 0) return 'Сценарий будет доступен после завершения глав.';
        return "Style Instructions: Read aloud in a warm, welcoming tone.\n\n" + completedChapters.map((chapter, index) => `ГЛАВА ${index + 1}: ${chapter.title.toUpperCase()}\n\n` + chapter.script.map(line => line.speaker.toUpperCase() === 'SFX' ? `[SFX: ${line.text}]` : `${line.speaker}: ${line.text}`).join('\n')).join('\n\n---\n\n');
    }, [podcast?.chapters]);
    
    return {
        isCombiningAudio,
        isGeneratingSrt,
        isZipping,
        combineAndDownload, 
        generateSrt, 
        downloadProjectAsZip,
        manualTtsScript
    };
};